# Change Log

## [1.0.0] 2020-09-27
### Original Release
- Added Material-UI as base framework
- Added ASP.NET Core 3.1 as back-end framework
- Added design and components from Material Dashboard React v1.9.0 by Creative Tim
