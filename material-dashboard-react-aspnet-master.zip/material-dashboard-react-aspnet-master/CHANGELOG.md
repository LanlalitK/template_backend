## [1.0.0] 2020-10-10
### Original Release
- based on Material Dashboard React **v1.9.0**
